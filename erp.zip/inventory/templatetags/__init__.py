"""Template tag package for inventory app."""
